package tp4.tp4_e2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp4E2Application {

	public static void main(String[] args) {
		SpringApplication.run(Tp4E2Application.class, args);
	}

}
